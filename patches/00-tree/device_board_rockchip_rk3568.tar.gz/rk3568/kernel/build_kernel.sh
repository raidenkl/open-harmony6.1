#!/bin/bash

# Copyright (c) 2021-2023 HiHope Open Source Organization .
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -e

pushd ${1}
ROOT_DIR=${5}
export PRODUCT_PATH=${4}
export DEVICE_COMPANY=${6}
export DEVICE_NAME=${7}
export PRODUCT_COMPANY=${8}
KERNEL_VERSION=${9}
KERNEL_FORM=${10}
KERNEL_PROD=${11}
ENABLE_LTO_O0=${12}

KERNEL_SRC_TMP_PATH=${ROOT_DIR}/out/kernel/src_tmp/${KERNEL_VERSION}
KERNEL_OBJ_TMP_PATH=${ROOT_DIR}/out/kernel/OBJ/${KERNEL_VERSION}
KERNEL_SOURCE=${ROOT_DIR}/kernel/linux/${KERNEL_VERSION}
KERNEL_PATCH_PATH=${ROOT_DIR}/kernel/linux/patches/${KERNEL_VERSION}
KERNEL_PATCH=${ROOT_DIR}/kernel/linux/patches/${KERNEL_VERSION}/rk3568_patch/kernel.patch
BUILD_SCRIPT_PATH=${3}
export KCFLAGS="-mno-outline-atomics ${KCFLAGS:-}"
# 板型选择：环境变量 > board.conf > 默认 v3
BOARD_CONF=${BUILD_SCRIPT_PATH}/kernel/board.conf
if [ -f "${BOARD_CONF}" ]; then . "${BOARD_CONF}"; fi
LUBANCAT_BOARD="${LUBANCAT_BOARD:-v3}"
LUBANCAT_DTS="rk3568-lubancat-2-${LUBANCAT_BOARD}-linux"
echo "[lubancat] board=${LUBANCAT_BOARD} dts=${LUBANCAT_DTS}"
NEWIP_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/newip/apply_newip.sh
TZDRIVER_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/tzdriver/apply_tzdriver.sh
XPM_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/xpm/apply_xpm.sh
CED_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/container_escape_detection/apply_ced.sh
HIDEADDR_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/memory_security/apply_hideaddr.sh
QOS_AUTH_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/qos_auth/apply_qos_auth.sh
UNIFIED_COLLECTION_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/ucollection/apply_ucollection.sh
CODE_SIGN_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/code_sign/apply_code_sign.sh
DEC_PATCH_FILE=${ROOT_DIR}/kernel/linux/common_modules/dec/apply_dec.sh

HARMONY_CONFIG_PATH=${ROOT_DIR}/kernel/linux/config/${KERNEL_VERSION}
DEVICE_CONFIG_PATH=${ROOT_DIR}/kernel/linux/config/${KERNEL_VERSION}/${DEVICE_NAME}
DEFCONFIG_BASE_FILE=${HARMONY_CONFIG_PATH}/base_defconfig
DEFCONFIG_TYPE_FILE=${HARMONY_CONFIG_PATH}/type/standard_defconfig
DEFCONFIG_FORM_FILE=${HARMONY_CONFIG_PATH}/form/${KERNEL_FORM}_defconfig
DEFCONFIG_ARCH_FILE=${DEVICE_CONFIG_PATH}/arch/arm64_defconfig
DEFCONFIG_PROC_FILE=${DEVICE_CONFIG_PATH}/product/${KERNEL_PROD}_defconfig

RAMDISK_ARG="disable_ramdisk"
MAKE_OHOS_ENV="GPUDRIVER=mali"
export KBUILD_OUTPUT=${KERNEL_OBJ_TMP_PATH}

source ${BUILD_SCRIPT_PATH}/kernel/kernel_source_checker.sh

for i in "$@"
do
    case $i in
        enable_ramdisk)
            RAMDISK_ARG=enable_ramdisk
            ;;
        enable_mesa3d)
            MAKE_OHOS_ENV="GPUDRIVER=mesa3d"
            ;;
    esac
done

function copy_and_patch_kernel_source()
{
    rm -rf ${KERNEL_SRC_TMP_PATH}
    mkdir -p ${KERNEL_SRC_TMP_PATH}

    rm -rf ${KERNEL_OBJ_TMP_PATH}
    mkdir -p ${KERNEL_OBJ_TMP_PATH}

    cp -arf ${KERNEL_SOURCE}/* ${KERNEL_SRC_TMP_PATH}/

    cd ${KERNEL_SRC_TMP_PATH}

    #HDF patch
    bash ${ROOT_DIR}/drivers/hdf_core/adapter/khdf/linux/patch_hdf.sh ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${KERNEL_PATCH_PATH} ${DEVICE_NAME}

    #update linux-6.6 kernel stdarg.h path to linux/stdarg.h
    if [ ${KERNEL_VERSION} == "linux-6.6" ]
    then
      sed -i 's/<stdarg.h>/<linux\/stdarg.h>/' ${KERNEL_SRC_TMP_PATH}/bounds_checking_function/include/securec.h
    fi

    #kernel patch
    patch -p1 < ${KERNEL_PATCH}

    # --- LubanCat: 注入板级 dts（V2/V3 由 LUBANCAT_BOARD 决定）---
    cp -f ${BUILD_SCRIPT_PATH}/kernel/dts/${LUBANCAT_DTS}.dts \
          ${KERNEL_SRC_TMP_PATH}/arch/arm64/boot/dts/rockchip/

    #newip
    if [ -f $NEWIP_PATCH_FILE ]; then
        bash $NEWIP_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #tzdriver
    if [ -f $TZDRIVER_PATCH_FILE ]; then
        bash $TZDRIVER_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #xpm
    if [ -f $XPM_PATCH_FILE ]; then
        bash $XPM_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #ced
    if [ -f $CED_PATCH_FILE ]; then
        bash $CED_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #qos_auth
    if [ -f $QOS_AUTH_PATCH_FILE ]; then
        bash $QOS_AUTH_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #hideaddr
    if [ -f $HIDEADDR_PATCH_FILE ]; then
        bash $HIDEADDR_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #ucollection
    if [ -f $UNIFIED_COLLECTION_PATCH_FILE ]; then
        bash $UNIFIED_COLLECTION_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #code_sign
    if [ -f $CODE_SIGN_PATCH_FILE ]; then
        bash $CODE_SIGN_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    #dec
    if [ -f $DEC_PATCH_FILE ]; then
        bash $DEC_PATCH_FILE ${ROOT_DIR} ${KERNEL_SRC_TMP_PATH} ${DEVICE_NAME} ${KERNEL_VERSION}
    fi

    cp -rf ${BUILD_SCRIPT_PATH}/kernel/logo* ${KERNEL_SRC_TMP_PATH}/

    #config
    if [ ! -f "$DEFCONFIG_FORM_FILE" ]; then
        DEFCONFIG_FORM_FILE=
        echo "warning no form config file $(DEFCONFIG_FORM_FILE)"
    fi
    if [ ! -f "$DEFCONFIG_PROC_FILE" ]; then
        DEFCONFIG_PROC_FILE=
        echo "warning no prod config file $(DEFCONFIG_PROC_FILE)"
    fi
    bash ${ROOT_DIR}/kernel/linux/${KERNEL_VERSION}/scripts/kconfig/merge_config.sh -O ${KERNEL_SRC_TMP_PATH}/arch/arm64/configs/ -m ${DEFCONFIG_TYPE_FILE} ${DEFCONFIG_FORM_FILE} ${DEFCONFIG_ARCH_FILE} ${DEFCONFIG_PROC_FILE} ${DEFCONFIG_BASE_FILE}
    mv ${KERNEL_SRC_TMP_PATH}/arch/arm64/configs/.config ${KERNEL_SRC_TMP_PATH}/arch/arm64/configs/rockchip_linux_defconfig

    #selinux config patch
    for arg in "$@"; do
        if [ "$arg" = "is_release" ]; then
            echo "close selinux kernel config CONFIG_SECURITY_SELINUX_DEVELOP in release version"
            ${KERNEL_SOURCE}/scripts/config --file ${KERNEL_SRC_TMP_PATH}/arch/arm64/configs/rockchip_linux_defconfig -d SECURITY_SELINUX_DEVELOP
        fi
    done

    if [ $MAKE_OHOS_ENV == "GPUDRIVER=mesa3d" ]; then
        python ${ROOT_DIR}/third_party/mesa3d/ohos/modifyDtsi.py ${KERNEL_SRC_TMP_PATH}/arch/arm64/boot/dts/rockchip/rk3568.dtsi
    fi
}

set +e
is_kernel_change ${ROOT_DIR}
KERNEL_SOURCE_CHANGED=$?
set -e
if [ ${KERNEL_SOURCE_CHANGED}  -ne 0 ]; then
    echo "kernel or it's deps changed, start source update."
    copy_and_patch_kernel_source
else
    echo "no changes to kernel, skip source copy."
fi

cd ${KERNEL_SRC_TMP_PATH}

# --- LubanCat: 修 OH 内核补丁的 ASoC API 不匹配（6.6 没有 snd_soc_dai_driver.probe）---
python3 ${BUILD_SCRIPT_PATH}/kernel/fix-audio-api.py ${KERNEL_SRC_TMP_PATH} || \\
    echo "[lubancat] 音频 API 兼容补丁失败（继续）"

# --- LubanCat: 把 make-ohos.sh 里 TB-RK3568X0 那行的 dtb 名换成本板（产物名仍是 toybrick.dtb）---
sed -i -E "s#(TB-RK3568X0[[:space:]]+arm64[[:space:]]+0xfe660000[[:space:]]+)[^[:space:]]+#\1${LUBANCAT_DTS}#" make-ohos.sh
grep -E "TB-RK3568X0" make-ohos.sh | head -1

eval $MAKE_OHOS_ENV ./make-ohos.sh TB-RK3568X0 $RAMDISK_ARG ${ENABLE_LTO_O0}

mkdir -p ${2}

if [ "enable_ramdisk" != "${13}" ]; then
    cp ${KERNEL_OBJ_TMP_PATH}/boot_linux.img ${2}/boot_linux.img
fi
cp ${KERNEL_OBJ_TMP_PATH}/resource.img ${2}/resource.img
cp ${3}/loader/MiniLoaderAll.bin ${2}/MiniLoaderAll.bin
cp ${3}/loader/uboot.img ${2}/uboot.img

if [ "enable_absystem" == "${15}" ]; then
    cp ${3}/loader/parameter_ab.txt ${2}/parameter_ab.txt
    cp ${3}/loader/config_ab.cfg ${2}/config_ab.cfg
else
    cp ${3}/loader/parameter.txt ${2}/parameter.txt
    cp ${3}/loader/config.cfg ${2}/config.cfg
fi

popd

# --- LubanCat 2 V3: 同步 extlinux append，确保 hardware=rk3568 / PARTUUID 不丢 ---
EXTLINUX_CONF=${KERNEL_SRC_TMP_PATH}/boot_linux/extlinux/extlinux.conf
if [ -f "${EXTLINUX_CONF}" ]; then
    sed -i 's#^[[:space:]]*append .*#append earlycon=uart8250,mmio32,0xfe660000 console=ttyFIQ0 ohos.boot.eng_mode=on root=PARTUUID=614e0000-0000 hardware=rk3568 default_boot_device=fe310000.sdhci rw rootwait#' "${EXTLINUX_CONF}"
    echo "[lubancat] extlinux.conf append synced"
fi

../kernel/src_tmp/${KERNEL_VERSION}/make-boot.sh ..

if [ ${KERNEL_SOURCE_CHANGED} -ne 0 ]; then
    cp ${ROOT_DIR}/out/kernel/checkpoint/last_build.info ${ROOT_DIR}/out/kernel/checkpoint/last_build.backup
    cp ${ROOT_DIR}/out/kernel/checkpoint/current_build.info ${ROOT_DIR}/out/kernel/checkpoint/last_build.info
    echo "kernel compile finish, save build info."
else
    echo "kernel compile finish."
fi
